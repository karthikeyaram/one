import React from 'react'

const Staffdetails = () => {
  return (
    <div>
      <h1>staff</h1>
    </div>
  )
}

export default Staffdetails
