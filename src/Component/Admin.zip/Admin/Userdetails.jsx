import React from 'react'

const Userdetails = () => {
  return (
    <div>
      <h1>UserDetails</h1>
    </div>
  )
}

export default Userdetails
