import React from 'react'

const Admindashboard = () => {
  return (
    <div>
      <div>
      <h1>Welcome to the Admin Dashboard</h1>
    </div>
    </div>
  )
}

export default Admindashboard
